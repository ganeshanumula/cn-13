# Experiment 13: Study of Wireshark

## Aim
To study Wireshark, a network protocol analyzer used for packet capture, analysis, filtering, and network troubleshooting.

## Requirements
- Windows or Linux computer
- Wireshark installed
- Active network interface (Wi-Fi or Ethernet)
- Administrator/root permissions may be required for packet capture

## Installation
### Windows
1. Visit the official website: https://www.wireshark.org/
2. Download the installer appropriate for your system.
3. Run the installer and follow the setup wizard.
4. Install Npcap when prompted; it is commonly required for live packet capture.
5. Launch Wireshark.

### Ubuntu/Debian
```bash
sudo apt update
sudo apt install wireshark
```

## Procedure
1. Open Wireshark and select the active network interface.
2. Start capturing packets.
3. Generate normal network activity, such as opening a website.
4. Stop the capture after collecting enough packets.
5. Select packets to inspect protocol layers, addresses, ports, and packet bytes.
6. Apply display filters to narrow the packet list.
7. Open **Statistics** to inspect Protocol Hierarchy, Endpoints, Conversations, and I/O Graphs.
8. Save the capture as `.pcapng` or `.pcap` for offline analysis.

## Useful display filters
| Purpose | Filter |
|---|---|
| HTTP packets | `http` |
| TCP packets | `tcp` |
| UDP packets | `udp` |
| DNS packets | `dns` |
| Packets involving an IP | `ip.addr == 192.168.1.10` |
| Packets from an IP | `ip.src == 192.168.1.10` |
| HTTPS/TLS traffic | `tls` |

## Useful capture filters
| Purpose | Filter |
|---|---|
| Traffic to or from a host | `host 192.168.1.10` |
| TCP port 80 | `tcp port 80` |
| Port 443 | `port 443` |
| DNS traffic | `port 53` |

## Command-line examples
Show command-line help:
```bash
wireshark -h
```

Read a saved capture:
```bash
wireshark -r capture.pcap
```

Open a capture with a display filter:
```bash
wireshark -r capture.pcap -Y "dns"
```

Capture using TShark (recommended for command-line capture):
```bash
tshark -i <interface> -f "tcp port 80" -w http_traffic.pcap
```

> Replace `<interface>` with an interface name or number available on your system. Interface names differ between Windows and Linux.

## Output
- Captured packets shown in the Wireshark packet list
- Filtered packets matching selected display filters
- Protocol and endpoint statistics
- A saved capture file for offline analysis

Add your own screenshots to the `output/` folder and your own `.pcap` or `.pcapng` capture files to `captures/` if required for submission.

## Safety and privacy
Capture only traffic on networks you own or are authorized to analyze. Packet captures may contain sensitive information. Avoid collecting passwords, personal data, or other private traffic, and do not publish raw captures publicly unless they have been reviewed and sanitized.

## Repository structure
```text
wireshark-experiment-13/
├── README.md
├── report.md
├── commands.txt
├── .gitignore
├── captures/
│   └── README.md
└── output/
    └── README.md
```
