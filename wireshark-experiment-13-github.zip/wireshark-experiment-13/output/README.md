# Experiment output

Add screenshots from your own Wireshark run here. Suggested filenames:

- `output_1_interface.png`
- `output_2_packets.png`
- `output_3_filter.png`
- `output_4_statistics.png`

Do not submit example screenshots as if they were captured from your own system.
