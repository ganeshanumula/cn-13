# Experiment 13 — Study of Wireshark

## Aim
The aim of this experiment is to study Wireshark, a network protocol analyzer used for packet capture, analysis, and network troubleshooting. The study includes installation, packet capture, packet analysis, filtering, and use of statistics tools.

## Problem Statement
- Install Wireshark on a Windows or Linux system.
- Capture live network traffic using the graphical interface and command line.
- Apply capture and display filters to isolate specific traffic.
- Analyze packets and identify protocols, source/destination addresses, and available packet content.
- Use statistics tools to understand network traffic patterns.
- Save and open capture files for offline analysis.

## Input
- Live network interface with internet connectivity
- Optional pre-saved capture file (`.pcap` or `.pcapng`)

## Software
Wireshark. On Windows, install Npcap if prompted during setup.

## Procedure

### Part A: Installation
1. Open https://www.wireshark.org/.
2. Download the installer suitable for the operating system.
3. Run the installer and follow the setup instructions.
4. On Windows, install Npcap when prompted.
5. Launch Wireshark.

For Ubuntu/Debian:
```bash
sudo apt update
sudo apt install wireshark
```

### Part B: Packet capture using the GUI
1. Launch Wireshark.
2. Select the active interface, such as Wi-Fi or Ethernet.
3. Start the capture.
4. Generate network activity.
5. Stop the capture.
6. Inspect packets in the Packet List pane.
7. Save the capture using **File → Save As**.

### Part C: Command-line use
Display help:
```bash
wireshark -h
```

Open a capture file:
```bash
wireshark -r capture.pcap
```

Open a capture with a display filter:
```bash
wireshark -r capture.pcap -Y "http"
```

For command-line packet capture, use TShark:
```bash
tshark -i <interface> -f "host 192.168.1.10" -w capture.pcap
```

### Part D: Viewing captured traffic
Select a packet in the Packet List pane. The Packet Details pane shows protocol layers and fields. The Packet Bytes pane shows hexadecimal and ASCII data where available.

### Part E: Applying filters
Display filter examples:
```text
http
ip.src == 192.168.1.10
ip.addr == 192.168.1.10
tcp
dns
```

Capture filter examples:
```text
host 192.168.1.10
tcp port 80
port 53
```

Capture filters are applied before/during capture; display filters control which already-captured packets are shown.

### Part F: Analysis and statistics
Use the **Statistics** menu to inspect:
- **Protocol Hierarchy:** protocol breakdown by packet/byte counts
- **Endpoints:** communicating MAC/IP/port endpoints
- **Conversations:** traffic between endpoint pairs
- **I/O Graphs:** traffic over time
- **Flow Graph:** packet sequence between hosts
- **Packet Lengths:** packet-size distribution

### Part G: Following TCP streams
1. Select a TCP packet.
2. Right-click and choose **Follow → TCP Stream**.
3. Inspect the reconstructed conversation, where protocol and encryption permit.

### Part H: Coloring rules
Open **View → Coloring Rules**. Existing rules help distinguish traffic types. Custom rules can be created using display-filter expressions.

## Example packet-list format
The following is an illustrative format only; actual addresses, protocols, packet lengths, and times depend on the capture.

| No. | Time | Source | Destination | Protocol | Length | Info |
|---:|---:|---|---|---|---:|---|
| 1 | 0.000000 | 192.168.1.10 | 192.168.1.1 | TCP | 66 | 50152 → 443 [SYN] |
| 2 | 0.012345 | 192.168.1.1 | 192.168.1.10 | TCP | 66 | 443 → 50152 [SYN, ACK] |
| 3 | 0.012456 | 192.168.1.10 | 192.168.1.1 | TCP | 54 | 50152 → 443 [ACK] |

## Output
- Packets captured and displayed in Wireshark
- Traffic isolated using capture/display filters
- Protocol, endpoint, and conversation statistics inspected
- Capture saved for offline analysis

## Constraints
- Packet capture may require administrator/root permissions.
- On switched networks, a device generally sees its own traffic and broadcast/multicast traffic, not all traffic from other devices.
- Busy captures can create large files.
- HTTPS, SSH, and other encrypted application traffic cannot normally be read as plaintext without appropriate session secrets and configuration.

## Result
Wireshark was studied for live packet capture, packet inspection, filtering, statistics, and saving captures for offline analysis.

## Evidence to add
Place screenshots of your own Wireshark session in `output/`, for example:
1. `output_1_interface.png` — interface selection or live capture
2. `output_2_packets.png` — packet list
3. `output_3_filter.png` — applied display filter
4. `output_4_statistics.png` — Protocol Hierarchy or Endpoints
