# Capture files

Place your own sanitized `.pcap` or `.pcapng` files here if your instructor requires them.

**Privacy:** Packet captures can contain sensitive information. Review and sanitize them before sharing publicly. Capture only traffic you are authorized to inspect.
